<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/info-card/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/info-card/info-card.php';