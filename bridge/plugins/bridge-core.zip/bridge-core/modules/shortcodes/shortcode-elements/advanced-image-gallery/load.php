<?php
include_once BRIDGE_CORE_SHORTCODES_PATH . '/advanced-image-gallery/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/advanced-image-gallery/advanced-image-gallery.php';